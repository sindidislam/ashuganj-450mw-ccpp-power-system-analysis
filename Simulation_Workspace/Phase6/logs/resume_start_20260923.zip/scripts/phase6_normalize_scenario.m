function S = phase6_normalize_scenario(P,override)
%PHASE6_NORMALIZE_SCENARIO One validated configuration for build and studies.
if nargin<2, override=struct(); end
S=P.scenario;
S.dispatch_MW=P.reference.primary.Gen_P_MW;
S.relayMask=true(1,7);
S.breakerFailed=false(1,5);
S.manualOpen=false(1,5);
S.manualOpenTime_s=Inf;
S.generatorTripTime_s=Inf;
S.measurementScale=ones(1,19);
names=fieldnames(override);
for k=1:numel(names)
    assert(isfield(S,names{k}),'Phase6:ScenarioField','Unknown scenario field: %s',names{k});
    S.(names{k})=override.(names{k});
end
assert(ismember(upper(string(S.networkProfile)),["PHASE3_BASELINE","PHASE5_STUDY"]));
assert(isfinite(S.dispatch_MW)&&S.dispatch_MW>=0&&S.dispatch_MW<=450);
assert(ismember(upper(string(S.faultType)),["3PH","SLG","LL","LLG"]));
assert(ismember(upper(string(S.faultLocation)),["GEN","GSUT_LV","GSUT_HV","GIS230","LINE230","GRID230","AUX66"]));
assert(isfinite(S.stopTime_s)&&S.stopTime_s>0);
assert(S.faultStart_s>2/P.f_Hz && S.faultDuration_s>0);
assert(S.faultResistance_ohm>0&&S.groundResistance_ohm>0);
assert(isequal(size(S.relayMask),[1 7])&&isequal(size(S.breakerFailed),[1 5]));
assert(isequal(size(S.manualOpen),[1 5])&&isequal(size(S.measurementScale),[1 19]));
assert(all(isfinite(S.measurementScale))&&all(S.measurementScale>=0));
assert(S.dcRestoreTime_s>=S.dcLossTime_s);
end
