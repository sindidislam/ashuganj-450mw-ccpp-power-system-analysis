# Teacher demonstration sequence

1. In MATLAB R2024a, run `setup_phase6_workspace`, then `build_phase6_model` from `Phase6/scripts`. Open the saved `Phase6/model/PHASE6_ASHUGANJ_CCPP_DYNAMIC_MODEL.slx` and identify G1 10MKA10, GCB 10BAC10, 22 kV bus, GSUT 10BAT10, 230 kV GIS, South line, external grid, UAT/GAT and auxiliary bus. Point out the vertically arranged unit chain and voltage colors copied from the original SLD.
2. Display the `LF360_GAT_OUT` reference and normal simulation. Show generator voltage, current, P/Q, speed and 230 kV bus quantities. Explain that 360 MW is the study dispatch and compare actual initialized quantities with the frozen Phase 3 CSV, including mismatches and tolerance status.
3. Select a 230 kV fault and one fault type, then run the scenario. Show **measured** current/voltage changes, CT secondary current, relay pickup, timer/trip output and the breaker opening. Note precisely which faulted section is isolated and which remains energized in this simplified network.
4. Inspect the protection detail and follow the real signal path: electrical sensor → CT ratio → relay timing → DC availability → trip coil → physical breaker. A relay indication alone is not proof of isolation.
5. Repeat with battery/charger supply unavailable. Show DC voltage, low-voltage and trip-circuit alarms and any inhibited breaker action. Restore healthy supply and reset the model for recovery.
6. Open the machine excitation/governor and battery subsystems. Identify assumed controller and 110 V station DC parameters. Close by showing the source classifications and unresolved plant-specific data in `PHASE6_ASSUMPTIONS.md`.

Use only scenarios verified in the generated acceptance report; if a scenario fails, present it as an open validation item rather than a successful demonstration.
