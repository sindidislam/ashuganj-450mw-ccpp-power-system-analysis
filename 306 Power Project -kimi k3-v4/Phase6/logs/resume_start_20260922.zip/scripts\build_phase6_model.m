function info = build_phase6_model(varargin)
%BUILD_PHASE6_MODEL Rebuild the isolated dynamic Ashuganj South study model.
% Never writes the original simulink/ or Phase 1-5 trees.
ip = inputParser;
ip.addParameter('SavePath','',@(x)ischar(x)||isstring(x));
ip.addParameter('Close',false,@(x)islogical(x)&&isscalar(x));
ip.addParameter('Scenario',struct(),@isstruct);
ip.parse(varargin{:});

phase6 = fileparts(fileparts(mfilename('fullpath')));
setup_phase6_workspace();
mdl = 'PHASE6_ASHUGANJ_CCPP_DYNAMIC_MODEL';
savePath = char(ip.Results.SavePath);
if isempty(savePath)
    savePath = fullfile(phase6,'model',[mdl '.slx']);
end
% Canonical paths block any accidental write through a relative path or junction.
base = char(java.io.File(phase6).getCanonicalPath());
dest = char(java.io.File(savePath).getCanonicalPath());
if ~startsWith(lower(dest),[lower(base) filesep]) || ...
        startsWith(lower(dest),[lower(base) filesep 'source_clone' filesep]) || ...
        ~strcmpi([mdl '.slx'],extractAfter(dest,find(dest==filesep,1,'last')))
    error('Phase6:UnsafeOutput','SavePath must be the Phase 6 model file outside source_clone: %s',dest);
end

P = init_phase6_parameters();
S = P.scenario;
override = ip.Results.Scenario;
names = fieldnames(override);
for k = 1:numel(names), S.(names{k}) = override.(names{k}); end

if bdIsLoaded(mdl), bdclose(mdl); end
new_system(mdl);
cleanup = onCleanup(@()closeOnError(mdl));
load_system(mdl);
set_param(mdl,'SolverType','Variable-step','Solver','ode23tb', ...
    'StartTime','0','StopTime','1.0','RelTol','1e-4','MaxStep','1e-3', ...
    'SaveTime','on','TimeSaveName','tout','SaveOutput','off', ...
    'SignalLogging','on','SignalLoggingName','logsout');
pg = add_block('sps_lib/powergui',[mdl '/powergui'], ...
    'Position',[45 85 150 125]);
set_param(pg,'SimulationMode','Continuous','frequency','50', ...
    'frequencyindice','50','Pbase','100e6');

mw = get_param(mdl,'ModelWorkspace');
assignin(mw,'P',P);
assignin(mw,'S',S);

net = phase6_add_network(mdl,P,S);
ctrl = phase6_add_controls(mdl,P,S,net);
titleNote = Simulink.Annotation([mdl '/phase6_title']);
titleNote.Text = sprintf(['ASHUGANJ SOUTH 450 MW CCPP  |  PHASE 6 DYNAMIC STUDY\n' ...
    '22 kV G1  >  GSUT 10BAT10  >  230 kV GIS  >  SOUTH LINE  >  PGCB EQUIVALENT']);
titleNote.Position = [180 -45 1650 45];
titleNote.FontSize = 16;
titleNote.FontWeight = 'bold';
titleNote.BackgroundColor = 'transparent';
statusNote = Simulink.Annotation([mdl '/phase6_status']);
statusNote.Text = sprintf(['STUDY MODEL  |  provenance: Phase6/docs/PHASE6_PARAMETER_REGISTER.md\n' ...
    '360 MW primary dispatch; generic AVR/governor and DC system are engineering assumptions.']);
statusNote.Position = [180 48 1650 86];
statusNote.FontSize = 10;
statusNote.BackgroundColor = 'transparent';

set_param(mdl,'SimulationCommand','update');
save_system(mdl,dest);
info = struct('model',mdl,'path',dest,'scenario',S,'network',net,'controls',ctrl);
if ip.Results.Close, close_system(mdl,0); end
clear cleanup
end

function closeOnError(mdl)
% Keep the generated model visible on successful interactive builds; on a
% failed build, discard the partial unsaved in-memory model.
if bdIsLoaded(mdl) && ~strcmp(get_param(mdl,'Dirty'),'off')
    close_system(mdl,0);
end
end
